#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "maze.h"
#include "state.h"

#define WALL '*'
#define TRAP '+'  // ������ ǥ���� ��ȣ
#define PATH ' '
#define EXIT 'E'

char maze[HEIGHT][WIDTH];  // ���� �̷� �迭

// DFS ��� Ž��
int dfs(int x, int y, int visited[HEIGHT][WIDTH]) {
    if (x < 0 || x >= HEIGHT || y < 0 || y >= WIDTH || visited[x][y]) return 0;
    if (maze[x][y] == EXIT) return 1;

    visited[x][y] = 1;
    if (maze[x][y] == WALL || maze[x][y] == TRAP) return 0;

    return dfs(x - 1, y, visited) || dfs(x + 1, y, visited) ||
        dfs(x, y - 1, visited) || dfs(x, y + 1, visited);
}

// �̷� ���� �Լ�
void generate_maze(int difficulty) {
    srand((unsigned int)time(NULL));

    int breakable_wall_count = (difficulty == 0) ? 20 : (difficulty == 1) ? 30 : 50;
    int trap_count = breakable_wall_count / 3;

    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            maze[i][j] = (i == 0 || i == HEIGHT - 1 || j == 0 || j == WIDTH - 1) ? '#' : PATH;
        }
    }

    for (int i = 0; i < breakable_wall_count;) {
        int x = rand() % (HEIGHT - 2) + 1;
        int y = rand() % (WIDTH - 2) + 1;

        if (maze[x][y] == PATH) {
            maze[x][y] = WALL;
            i++;
        }
    }

    for (int i = 0; i < trap_count;) {
        int x = rand() % (HEIGHT - 2) + 1;
        int y = rand() % (WIDTH - 2) + 1;

        if (maze[x][y] == WALL) {
            maze[x][y] = TRAP;
            i++;
        }
    }

    maze[HEIGHT - 2][WIDTH - 2] = EXIT;

    int visited[HEIGHT][WIDTH] = { 0 };
    if (!dfs(1, 1, visited)) generate_maze(difficulty);
}

// �̷� ��� �Լ�
void print_maze() {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (maze[i][j] == TRAP || maze[i][j] == WALL) {
                printf("*");  // ������ ���� �����ϰ� ���
            }
            else {
                printf("%c", maze[i][j]);
            }
        }
        printf("\n");
    }
}
