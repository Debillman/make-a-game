﻿#include "player.h"
#include "state.h"
#include "maze.h"

void move_player(char direction) {
    int next_x = player_x;
    int next_y = player_y;

    // 이동 방향에 따라 다음 좌표 설정
    if (direction == 'w') {
        next_x--;
        player_direction = 'w';  // 현재 방향 설정
    }
    else if (direction == 's') {
        next_x++;
        player_direction = 's';
    }
    else if (direction == 'a') {
        next_y--;
        player_direction = 'a';
    }
    else if (direction == 'd') {
        next_y++;
        player_direction = 'd';
    }

    // 이동 가능 여부 확인
    if (maze[next_x][next_y] == PATH || maze[next_x][next_y] == EXIT) {
        player_x = next_x;
        player_y = next_y;

        // 출구 도달 여부 확인
        if (maze[next_x][next_y] == EXIT) {
            printf("\n탈출 성공! 축하합니다!\n");
            gameOver = 1;
            escaped = 1;
        }
    }
}

void break_wall() {
    int break_x = player_x;
    int break_y = player_y;

    // 바라보는 방향에 따라 벽 파괴 좌표 설정
    if (player_direction == 'w') break_x--;
    else if (player_direction == 's') break_x++;
    else if (player_direction == 'a') break_y--;
    else if (player_direction == 'd') break_y++;

    // 벽 처리 로직
    if (maze[break_x][break_y] == WALL) {
        maze[break_x][break_y] = PATH;
        remaining_time -= 2;
        printf("벽을 파괴했습니다. 남은 시간: %d초\n", remaining_time);
    }
    else if (maze[break_x][break_y] == TRAP) {
        printf("\n 함정을 건드렸습니다! 게임 오버!\n");
        gameOver = 1;
    }
    else {
        printf("여긴 부술 수 있는 곳이 아닙니다!\n");
    }
}
