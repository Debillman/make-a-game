﻿#include <stdio.h>
#include <conio.h>
#include "state.h"
#include "menu.h"
#include "maze.h"
#include "title.h"
#include "player.h"
#include "draw.h"

int main() {
    show_title();                   // 타이틀 화면 출력
    initialize_game_state();        // 게임 상태 초기화

    difficulty = select_difficulty();  // 난이도 선택
    generate_maze(difficulty);         // 선택한 난이도에 따른 미로 생성

    while (!gameOver) {
        draw_game();  // 화면 출력

        char input = _getch();
        if (input == ' ') {
            break_wall();   // 벽 파괴
        }
        else {
            move_player(input);  // 플레이어 이동
        }

        remaining_time--;
        if (remaining_time <= 0) {
            printf("\n시간 초과! 게임 오버!\n");
            gameOver = 1;
            break;
        }
    }

    // 탈출 성공/실패에 따라 결과 메시지 출력
    if (escaped) {
        printf("\n탈출 성공! 축하합니다!\n");  // 탈출 성공 메시지만 출력
    }
    else {
        printf("\n게임 오버! 다시 도전하세요!\n");  // 실패 메시지만 출력
    }

    return 0;
}
