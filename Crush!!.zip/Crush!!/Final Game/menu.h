#ifndef MENU_H
#define MENU_H

int select_difficulty();

#endif
